class AudioEffect {
	
	/**
	 * 
	 * TODO: Implement this function
	 * 
	 * @param in Source array
	 * @param out Destination array
	 * @param delayInSeconds How much the echo effect should 'lag'
	 * @param strength Strength of the echo effect (0.0 <= strength <= 1.0) 
	 */
	static void echo(double[] in, double[] out, double delayInSeconds, double strength) {
		
	}
}
